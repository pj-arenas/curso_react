const Note = ({ note }) => {
  return (
    <li>{note.content}</li>
  )
}

export default Note